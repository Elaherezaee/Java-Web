﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Ex1_PerEva_Queueing
{
    //Count:	Gets the number of elements contained in the Queue.
    //Enqueue:	Adds an object to the end of the Queue.    
    //Peek:	Returns the object at the beginning of the Queue without removing it.
    //Dequeue:	Removes and returns the object at the beginning of the Queue.



    class SimulatedQueueing
    {

        /*******************************
         * Variables
         ******************************/
        int K;//capacity of queue
        int stableTime;
        int numOfSimulatedClient;
        double miu;//Serving Rate 
        double teta;//Deadline Rate : fixed or Exponential 
        double lambda;//Entering Rate 

        bool fixedTeta;// if(Fixedteta) deadLineTime = entringTime + teta; else deadLineTime = entringTime + exp(1/teta);

        /******************************
         * Functions
         *****************************/

        /*------------------------  Constructor  -------------------------*/
        public SimulatedQueueing(int KIn, int numOfSimulatedClientIn, int stableTimeIn, double miuIn, double tetaIn, double lambdaIn, bool fixedTetaIn)
        {

            K = KIn;
            //stableNumClients = stableNumClientsIn;
            stableTime = stableTimeIn;
            numOfSimulatedClient = numOfSimulatedClientIn;
            miu = miuIn;
            teta = tetaIn;
            lambda = lambdaIn;

            fixedTeta = fixedTetaIn;

        }//end SimulatedQueueing()
        /*------------------------  Deconstructor  -------------------------*/
        //public ~SimulatedQueueing()
        //{

        //}//end ~SimulatedQueueing

        /*-------------------  Exponential Distribution    ------------------*/
        double exp(double mu)
        {

            double expNumber = 0;
            double uniformRandom;


            /***************************************/
            CryptoRandom rnd = new CryptoRandom();
            uniformRandom = rnd.NextDouble();

            /*************************************** Other Random Generator that we tested!!!! **************/
           /* Random autoRand = new Random(Environment.TickCount);
            Random autoRand = new Random(DateTime.Now.Millisecond);
            uniformRandom = autoRand.NextDouble();

            int NN = 1000000000;
            Random r = new Random(DateTime.Now.Millisecond);
            uniformRandom = r.NextDouble(); //r.NextDouble();//(double)(r.Next(0, NN - 1) / (double)NN);

            Random r = new Random(DateTime.Now.Millisecond);//(Environment.TickCount);

            do
            {
                uniformRandom = (double)(r.Next(0, NN - 1) / (double)NN);//it is acuurate!//r.NextDouble();

            } while ((uniformRandom == 0) || (uniformRandom == 1));//((1 - uniformRandom) <= 0); // if 1-uniformRandom == 0 log 0 => binahAyat || 1-uniform ==1 log 1 =0 => 2 client ruye ham miyoftan ..

            */
            expNumber = -(mu * Math.Log((1 - uniformRandom)));
            return expNumber;


        }

        /*------------------------  enqueueToQueue  -------------------------*/
        bool enqueueToQueue(Queue<Client> thisQueue, Client thisClient, Server[] thisServerArray)
        {

            bool addToQueue = false;
            int totalNumOfClientInSysytem = 0;//queue and servers

            for (int i = 0; i < thisServerArray.Length; i++)
            {

                if (thisServerArray[i].statusOfThisServer == StatusOfServers.BUSY)
                    totalNumOfClientInSysytem++;

            }

            totalNumOfClientInSysytem = totalNumOfClientInSysytem + thisQueue.Count();


            if (totalNumOfClientInSysytem < K)
            {
                thisQueue.Enqueue(thisClient);
                addToQueue = true;
            }
            else
            {
                addToQueue = false;
            }


            return addToQueue;

        }


        /*--------------  Dequeue a Specific Element in Queue -----------*/
        Queue<Client> removeSpecifoedElement(Queue<Client> waitingQueueRemove, int specifiedIndex)
        {
            Client[] copyArray = new Client[waitingQueueRemove.Count];
            waitingQueueRemove.CopyTo(copyArray, 0);
           
            List<Client> copyList = new List<Client>();
            for (int ix = 0; ix < copyArray.Length; ix++)
            {
                if (ix != specifiedIndex)
                    copyList.Add(copyArray[ix]);
            }

            waitingQueueRemove.Clear();
            for (int ix = 0; ix < copyList.Count; ix++)
            {
                waitingQueueRemove.Enqueue(copyList[ix]);
            }

            return waitingQueueRemove;
        }

        /*--------------------   initializeClients   ---------------------*/
        Client[] initializeClients(Client[] initiatedClientArray)
        {

            double beforeEnterTime = 0;

            for (int index = 0; index < initiatedClientArray.Length; index++)
            {
                /*-----------------------------------------*/
                initiatedClientArray[index].idOfClient = index;

                /*-----------------------------------------*/
                initiatedClientArray[index].enteringTime = beforeEnterTime + exp(1 / lambda);
                beforeEnterTime = initiatedClientArray[index].enteringTime;

                /*-----------------------------------------*/
                initiatedClientArray[index].servingDuration = 0;

                /*-----------------------------------------*/
                if (fixedTeta)
                {
                    initiatedClientArray[index].deadLineDuration = teta;//fixedTeta
                }
                else
                {
                    initiatedClientArray[index].deadLineDuration = exp(teta);//Exp Dist. for teta
                }

            }            

            return initiatedClientArray;
        }

        /*--------------------   min between 3 Numbers   ---------------------*/
        double funcMin3Num(double num1, double num2, double num3)
        {

            double myExtreme = 1000000000000000;// = binahAyat
            double minOf3Numbers = myExtreme;// = binahAyat

            double min1 = Math.Min(num1, num2);
            double min2 = Math.Min(num1, num3);

            minOf3Numbers = Math.Min(min1, min2);

            return minOf3Numbers;
        }

        /*--------------------   checkTerminationCondition   ---------------------*/
        bool checkTerminationCondition(Queue<Client> thisWaitingQueue, Server[] serverArray, int indexEnteredClients)
        {

            bool terminatedOrNot = false;
            int numEnteredClients = indexEnteredClients + 1;
            if ((numEnteredClients == numOfSimulatedClient)
                && (thisWaitingQueue.Count == 0)
                && (serverArray[0].statusOfThisServer == StatusOfServers.FREE_SERVER)
                && (serverArray[1].statusOfThisServer == StatusOfServers.FREE_SERVER))
            {

                terminatedOrNot = true;

            }


            return terminatedOrNot;

        }
        /*----------------------------------------------------
            Simulation Function
         ---------------------------------------------------*/
        public /*void*/double[] simFunc(System.IO.StreamWriter FileToWrite)
        {
            double myExtreme = 1000000000000000;// = binahAyat
            /*========  Waiting Queue   =========*/
            Queue<Client> waitingQueue = new Queue<Client>();

            /*========  Server Array   =========*/
            Server[] serverArray = new Server[2];
            //new for each element is necessary!
            for (int ixArray = 0; ixArray < serverArray.Length; ixArray++)
                serverArray[ixArray] = new Server();
            /*========  Client Array   =========*/
            Client[] clientArray = new Client[numOfSimulatedClient];
            //new for each element is necessary!
            for (int ixArray = 0; ixArray < clientArray.Length; ixArray++)
                clientArray[ixArray] = new Client();

            clientArray = initializeClients(clientArray);


            /*========  Variables for Simulation Loop   ========*/
            bool terminationCondition = false;
            int indexEnteredClients = 0;
            int numMissedDeadlineClients = 0;
            int numBlockedClients = 0;

            int numOfComputedClients = 0;
            // double lastEnterTime = 0;
            //double timeStep = 0.1;
            double tCurrent = 0;//current time
            double tServiceEnding0;// = myExtreme;//time of end services of Server #1
            double tServiceEnding1;// = myExtreme;//time of end services of Server #2
            double tEnteringToQueue;// = myExtreme;//entring time of next member in waitingQueue


            while (!terminationCondition)
            {


                /*=========================
                 initialize times
                 =========================*/
                /*~~~~~~~~~~    tServiceEnding1     ~~~~~~~~~*/
                if (serverArray[0].statusOfThisServer == StatusOfServers.BUSY)
                {
                    int clientID = serverArray[0].idOfServedClient;
                    tServiceEnding0 = serverArray[0].enterTimeOfClient + clientArray[clientID].servingDuration;
                }
                else
                {
                    tServiceEnding0 = myExtreme;
                }

                /*~~~~~~~~~~    tServiceEnding2     ~~~~~~~~~*/
                if (serverArray[1].statusOfThisServer == StatusOfServers.BUSY)
                {
                    int clientID = serverArray[1].idOfServedClient;
                    tServiceEnding1 = serverArray[1].enterTimeOfClient + clientArray[clientID].servingDuration;
                }
                else
                {
                    tServiceEnding1 = myExtreme;
                }

                /*~~~~~~~~~~    tEnteringToQueue     ~~~~~~~~~*/
                if (indexEnteredClients < (numOfSimulatedClient - 1))
                {
                    if ((!clientArray[indexEnteredClients].enterd))
                    { /*????*/ //hanuz be akhar nareside!: < last index = 1000000 - 1 : age be in reside bashe yani hamashun ro ghablan borde tu queue!
                        tEnteringToQueue = clientArray[indexEnteredClients].enteringTime;
                    }
                    else
                    {
                        tEnteringToQueue = myExtreme;
                    }
                }
                else
                {
                    tEnteringToQueue = myExtreme;
                }

                /*=========================
                set current time
                =========================*/
                tCurrent = funcMin3Num(tServiceEnding0, tServiceEnding1, tEnteringToQueue);
                /*=========================
                 checkMissedDeadLineClients : it should be given above
                 =========================*/
                for (int indexQueue = 0; indexQueue < waitingQueue.Count; indexQueue++)
                {
                    Client determinedClient = waitingQueue.ElementAt(indexQueue);
                    double checkDeadline = determinedClient.enteringTime + determinedClient.deadLineDuration;

                    if (tCurrent > checkDeadline)
                    {
                        if (tCurrent > stableTime) numMissedDeadlineClients++;// if simulation is stable! : baghiye amma anjam she!

                        /* delete given element from waiting queue*/
                        waitingQueue = removeSpecifoedElement(waitingQueue, indexQueue);
                        indexQueue--;

                    }

                }

                /*========================================================================
                 functions in differenrt time! for:  client Array , servers ,waitingQueue :
                  waitingQueue to Servers;
                  clientArray to waitingQueue; 
                  Servers to exit!;
                 =====================================================================*/

                /*~~~~~ Servers to exit!    ~~~~~*/
                for (int ixServer = 0; ixServer < serverArray.Length; ixServer++)
                {

                    if (serverArray[ixServer].statusOfThisServer == StatusOfServers.BUSY)
                    {
                        int clientID = serverArray[ixServer].idOfServedClient;
                        double tEndOfService = serverArray[ixServer].enterTimeOfClient + clientArray[clientID].servingDuration;

                        if ((tCurrent >= tEndOfService))
                        {
                            serverArray[ixServer].deAssignClientToThisServer();
                        }

                    }

                }


                /*~~~~~ waitingQueue to Servers    ~~~~~*/

                for (int ixServer = 0; ixServer < serverArray.Length; ixServer++)
                {
                    if ((serverArray[ixServer].statusOfThisServer == StatusOfServers.FREE_SERVER) && (waitingQueue.Count > 0))
                    {

                        Client givenClient = waitingQueue.Dequeue();
                        serverArray[ixServer].assignClientToThisServer(givenClient.idOfClient, tCurrent);
                        clientArray[givenClient.idOfClient].servingDuration = exp(miu);

                    }
                }



                bool enqueueOrNot = false;

                /*~~~~~ clientArray to waitingQueue    ~~~~~*/
                if ((tCurrent >= tEnteringToQueue) && (!clientArray[indexEnteredClients].enterd))
                {
                    enqueueOrNot = enqueueToQueue(waitingQueue, clientArray[indexEnteredClients], serverArray);
                    if (!enqueueOrNot)
                    {
                        if (tCurrent > stableTime) numBlockedClients++;
                    }

                    clientArray[indexEnteredClients].enterd = true;
                    indexEnteredClients++; //dar har surat yek client e dige barreSi shode!
                    if (tCurrent > stableTime) numOfComputedClients++;



                    if (enqueueOrNot && (waitingQueue.Count == 1))
                    {
                        for (int ixServer = 0; ixServer < serverArray.Length; ixServer++)
                        {
                            if ((serverArray[ixServer].statusOfThisServer == StatusOfServers.FREE_SERVER))
                            {

                                Client givenClient = waitingQueue.Dequeue();
                                serverArray[ixServer].assignClientToThisServer(givenClient.idOfClient, tCurrent);
                                clientArray[givenClient.idOfClient].servingDuration = exp(miu);
                                break;

                            }
                        }
                    }
                }

                /*=========================
                 checking TerminationCondition
                 =========================*/
                terminationCondition = checkTerminationCondition(waitingQueue, serverArray, indexEnteredClients);

            }

    
            double pd = (double)numMissedDeadlineClients / numOfComputedClients;//only compute in stable duration!//numOfSimulatedClient;//missedDeadline
            double pBlocking = (double)numBlockedClients / numOfComputedClients;//only compute in stable duration!//numOfSimulatedClient;//blocking


            double[] mathresults = MathCheck(K, teta, lambda); // 0->PD && 1->PB
            double deltaPB = Math.Abs(pBlocking - mathresults[1]);
            double deltaPD = Math.Abs(pd - mathresults[0]);
          
            FileToWrite.WriteLine(pBlocking + "\t" + mathresults[1] + "\t" + deltaPB + "\t" + pd + "\t" + mathresults[0] + "\t" + deltaPD);


            Console.WriteLine("************************************************");

            if (deltaPB < 0) deltaPB = deltaPB * -1;
            if (deltaPD < 0) deltaPD = deltaPD * -1;

            double[] resultArray = { deltaPD, deltaPB };

            return resultArray;

        }

        public double[] MathCheck(int k, double teta, double lambda)
        {

            double P0 = 0.00;
            double PB = 0.00;
            double PD = 0.00;
            double PK = 0.00;

            double[] results = new double[2]; // 0->PD && 1->PB


            double sum = 0.00;
            for (int i = 0; i <= k; i++)
            {
                if (i == 1)
                {
                    sum += lambda;
                }

                if (i == 2)
                {
                    sum += (Math.Pow(lambda, 2.00) / 2.00);
                }

                if (i > 2)
                {
                    double cal = ((Math.Pow(lambda, i) * fi(i - 2, 2, teta)) / (Fact(i - 2)));
                    sum += cal;

                    if (i == k)
                    {
                        PK = cal;

                    }
                }

            }

            P0 = 1 / (sum + 1);
            PB = PK * P0;
            PD = 1 + P0 - PB - ((2 / lambda) * (1 - P0));

            results[0] = PD;
            results[1] = PB;


            return results;

        }


        public double fi(int n, int c, double teta)
        {
            double result = 0.00;
            double help = 0.00;
            double help2 = 1.00;
            double first = 0.00;


            if (fixedTeta)
            {

                first = ((Fact(n)) / (Math.Pow((double)c, (double)(n + 1))));
                for (int i = 0; i <= n - 1; i++)
                {
                    help += (Math.Pow(((double)c * teta), (double)i) / Fact(i));

                }
                result = first * (1 - ((Math.Pow(Math.E, (-1 * c * teta))) * help));
            }

            else if (!fixedTeta)
            {
                for (int i = 0; i <= n; i++)
                {

                    help2 = help2 * (c + (i / teta));
                }

                result = Fact(n) / help2;
            }
            return result;
        }


               static int Fact(int n)
        {

            if (n <= 1)

                return 1;

            return n * Fact(n - 1);

        }


    }//end class
}