﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



namespace Ex1_PerEva_Queueing
{
    class Client
    {

       /*******************************
        * Variables
        ******************************/

        public int idOfClient;
        /*long*/
        public double enteringTime;//lambda
        /*long*/
        public double servingDuration;//miue
        /*long*/
        public double deadLineDuration;//gama: Fixed or Exponential

        public bool enterd;//false = not enter yet ; true = enter to simu;ation

        /******************************
         * Functions
         *****************************/

        /*------------------------  Constructor  -------------------------*/
         public Client(){


            this.enterd = false;

            /*temporal*/
            this.idOfClient = -1;
            this.enteringTime = 0;
            this.servingDuration = 0;
            this.deadLineDuration = 0;
        
        }//Client



    }

}
