﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex1_PerEva_Queueing
{

    class Simulator
    {
        static int K = 12;//capacity of queue 
        static int stableTime = 100;
        static int numOfSimulatedClient = 1000000;
        static double miu = 1;//Serving Rate 
        static double teta = 2;//Deadline Rate : fixed or Exponential 
        static bool FixedTeta = true;//true;//teta is fixed or have exp dist.// if(Fixedteta) deadLineTime = entringTime + teta; else deadLineTime = entringTime + exp(teta);
       
        
        /*------------------------  main  -------------------------*/
        static void Main() {

            Console.WriteLine("Please Enter The Num Of Simulated Clients: (defualt:1000000)");
            string NumoFC = Console.ReadLine();
            if(NumoFC !="")
            numOfSimulatedClient = Convert.ToInt32(NumoFC);

                    Console.WriteLine("Const Teta: 0 OR Exp Teta: 1?");
                    string line = Console.ReadLine();
                    string filename = "";

                    if (line == "0")
                    {
                        FixedTeta = true;
                        filename = "ConstantTeta";
                    }
                    else if (line == "1")
                    {
                        FixedTeta = false;
                        filename = "ExpTeta";
                    }
                   
                    System.IO.StreamWriter FileToWrite = new System.IO.StreamWriter(filename+".txt");
                    FileToWrite.WriteLine("Lnada\tSim-PB\tAna-PB\tDeltaPB\tSim-PD\tAna-PD\tDeltaPD");



                    int arrayCount = 0;

                    List<double> lambdaArray = new List<double>();
                    double lambda;

                    /*--------------    Initialization lambdaArray   ----------------*/
                    for (int i = 1; i <= 200; i++)
                    {
                        lambdaArray.Add(i * (0.1));
                        arrayCount++;
                    }

                    /*--------------Arrays Of results----------------*/
                    List<double> deltaPBArray = new List<double>();
                    List<double> deltaPDArray = new List<double>();

                    /*--------------CALL SimulatedQueueing ------------*/
                    for (int indexOflambdaArray = 0; indexOflambdaArray < lambdaArray.Count; indexOflambdaArray++)
                    {
 
                        lambda = lambdaArray[indexOflambdaArray];

                        Console.WriteLine("new Lambda = " + lambda);
                        FileToWrite.Write(lambda + "\t");

                        SimulatedQueueing simQueue = new SimulatedQueueing(K, numOfSimulatedClient, stableTime, miu, teta, lambda, FixedTeta);
                        double[] simResults = simQueue.simFunc(FileToWrite);

                        deltaPDArray.Add(simResults[0]);
                        deltaPBArray.Add(simResults[1]);
                       
                    }

                    double maxErrorOfPDs = deltaPDArray.Max();
                    double maxErrorOfPBs = deltaPBArray.Max();

                    double avgErrorOfPDs = deltaPDArray.Average();
                    double avgErrorOfPBs = deltaPBArray.Average();



                    Console.WriteLine("- - - - - - - - - - - - - - - - - - - - -");
                    Console.WriteLine("Max Delta PB\t" + maxErrorOfPBs); //Blocking
                    Console.WriteLine("Max Delta PD\t" + maxErrorOfPDs); //Missing Deadline

                    Console.WriteLine("- - - - - - - - - - - - - - - - - - - - -");
                    Console.WriteLine("Average PB\t" + avgErrorOfPBs); //Blocking
                    Console.WriteLine("Average PD\t" + avgErrorOfPDs); //Missing Deadline



                    FileToWrite.WriteLine("- - - - - - - - - - - - - - - - - - - - -");
                    FileToWrite.WriteLine("Max Delta PB\t" + maxErrorOfPBs); //Blocking
                    FileToWrite.WriteLine("Max Delta PD\t" + maxErrorOfPDs); //Missing Deadline

                    FileToWrite.WriteLine("- - - - - - - - - - - - - - - - - - - - -");
                    FileToWrite.WriteLine("Average PB\t" + avgErrorOfPBs); //Blocking
                    FileToWrite.WriteLine("Average PD\t" + avgErrorOfPDs); //Missing Deadline

                    FileToWrite.Close();
                   
               
        }//end main




    }//end class Simulator
}
