﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex1_PerEva_Queueing
{
    /*******************************
   * Enumeration
   ******************************/
    public enum StatusOfServers { FREE_SERVER, BUSY };//define at before of this class So it known by other classes 
    
    class Server
    {


        /*******************************
        * Variables
        ******************************/
        public StatusOfServers statusOfThisServer;//true
        public int idOfServedClient;
        public double enterTimeOfClient;

        /*******************************
        * Functions
        ******************************/

        /*------------------------  Constructor  -------------------------*/
        public Server(){
            deAssignClientToThisServer();
        }

        /*------------------------  AssignClientToThisServer  -------------------------*/
       public void assignClientToThisServer(int id, double currTime)
       {

           this.statusOfThisServer = StatusOfServers.BUSY;
           this.idOfServedClient = id;
           this.enterTimeOfClient = currTime;
       
       }


       /*------------------------  DeAssignClientToThisServer  -------------------------*/
       public void deAssignClientToThisServer() {

           this.statusOfThisServer = StatusOfServers.FREE_SERVER;
           this.idOfServedClient = -1;
           this.enterTimeOfClient = -1;
       
       }
      

    }
}
